package com.baizhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElasticsearchDay2Application {

    public static void main(String[] args) {
        SpringApplication.run(ElasticsearchDay2Application.class, args);
    }

}
