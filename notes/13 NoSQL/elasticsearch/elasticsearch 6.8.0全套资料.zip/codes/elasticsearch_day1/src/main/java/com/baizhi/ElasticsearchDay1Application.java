package com.baizhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElasticsearchDay1Application {

    public static void main(String[] args) {
        SpringApplication.run(ElasticsearchDay1Application.class, args);
    }

}
